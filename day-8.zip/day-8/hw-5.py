data = ["salom", "dastur", 2.5, "yordam", 34, "kitob"]

lugat = {
    "salom": "hello",
    "dastur": "program",
    "yordam": "help",
    "kitob": "book"
}

result = {}

for item in data:
    if isinstance(item, str) and item in lugat:
        result[item] = lugat[item]

print(result)