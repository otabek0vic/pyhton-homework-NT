import datetime

bugun = datetime.date.today()
yil = bugun.year

mustaqillik = datetime.date(yil, 9, 1)
if bugun > mustaqillik:
    mustaqillik = datetime.date(yil + 1, 9, 1)

qolgan_kun = (mustaqillik - bugun).days

print(f"Keyingi Mustaqillik bayramiga {qolgan_kun} kun qoldi.")