import datetime
x = datetime.date.today()
print(f"Bugunki sana: {x}")