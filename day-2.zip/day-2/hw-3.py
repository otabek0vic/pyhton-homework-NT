x = input("son kiriting: ")

for i in x:
    print(i, end=" ")