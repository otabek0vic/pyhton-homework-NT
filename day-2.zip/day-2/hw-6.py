x = int(input("son kiriting: "))

while x > 0:
    print(x % 10, end=" ")
    x //= 10