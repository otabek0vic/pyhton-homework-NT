x = int(input("Son kiriting: "))
sum = 0
for i in range(1, x + 1):
    sum += i
print(f"1 dan kiritgan soningizgacha bo'lgan sonlar yig'indisi: {sum}")