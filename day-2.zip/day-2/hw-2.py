x = int(input("Son kiriting: "))
for i in range(x, 0, -1):
    if i % 2 == 0:
        print(i, end = " ")
print()