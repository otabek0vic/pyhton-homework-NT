products = {
    "olma": [13000, 14000, 15000],
    "anor": [19000, 22000, 24000, 15000],
    "gilos": [6000, 9000, 5000, 4000],
    "banan": [30000, 28000]
}

def avg_prices(data):
    for product, prices in data.items():
        avg = sum(prices) // len(prices)
        print(f"{product}: {avg}")

avg_prices(products)