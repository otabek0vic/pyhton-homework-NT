def bank_hisob(depozit, foiz, yil):
    final_sum = depozit + (depozit * foiz / 100 * yil)
    return int(final_sum)

natija = bank_hisob(10000, 24, 3)
print(natija)