users = [
    'Abdulla Abdullaev',
    'Samandar Asadov',
    'Shaxnoza Jurayeva',
    'Ikrom Karimov',
    'Gulnora Xalilova',
    'Ziyoda Yuldashova'
]

men = []
women = []

for user in users:
    familya = user.split()[-1]

    if familya.endswith(("ov", "ev")):
        men.append(user)
    elif familya.endswith("va"):
        women.append(user)

print("Erkaklar:", men)
print("Ayolar:", women)