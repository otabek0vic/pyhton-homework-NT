try:
    file = open("./Homeworks/day-9/hw4.txt", "r")
    numbers = file.read().split()
    file.close()

    nums = list(map(int, numbers))

    average = sum(nums) / len(nums)

    result = round(average)

    print("O'rtacha qiymat:", result)

except:
    print("Xatolik yuz berdi!")