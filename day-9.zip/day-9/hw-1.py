try:
    file = open("./Homeworks/day-9/hw1.txt")
except:
    print("Xatolik !!!")
numbers = file.read().split()

text = ""

try:
    new = open("./Homeworks/day-9/hw1-new.txt", "w")
except:
    print("Xatolik !!!")

for num in numbers:
    text += chr(int(num))
new.write(text)
new.close()
print(text)