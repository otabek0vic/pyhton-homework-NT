try:
    file = open("./Homeworks/day-9/hw2.txt")

    text = file.read()
    file.close()

    x = input("text kiriting: ")
    y = text.find(x)
    if y != -1:
        print("Siz kiritgan so'z faylda bor.")
    else:
        print("Ushbu text fayl ichida topilmadi")

except:
    print("Xatolik !!!")