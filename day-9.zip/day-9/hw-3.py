try:
    file = open("./Homeworks/day-9/hw3.txt", "r")
    text = file.read()
    file.close()

    new_text = text.title()

    new_file = open("./Homeworks/day-9/hw3-new.txt", "w")
    new_file.write(new_text)
    new_file.close()

    print("Matn muvaffaqiyatli o'zgartirildi.")
except:
    print("Xatolik yuz berdi!")